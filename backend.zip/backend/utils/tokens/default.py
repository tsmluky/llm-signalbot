def get_context() -> str:
    return """📌 **Contexto general para tokens no identificados:**

No se ha definido un contexto específico para este token. Se realizará el análisis en base a la estructura de mercado, datos técnicos y la consulta del usuario.  
Se recomienda interpretar con precaución si se trata de activos de baja capitalización o tokens emergentes con poca información histórica.
"""
